from machine import Pin, mem32
import time, random

# Registros para LEDs
OUT, EN = 0x3FF44004, 0x3FF44020  # EN para establecerlos como salidas y EN establecer el estado de salida
LEDS = [1<<22, 1<<21, 1<<19]  # GPIO22,21,19
mem32[EN] = LEDS[0]|LEDS[1]|LEDS[2] 

# Pines
btninicio = Pin(33, Pin.IN, Pin.PULL_DOWN) # .IN establecer el pin como entrada y ,PULL_DOWN activar las resistencias internas de la ESP

# Botones del jugador 1
btn_j1 = [Pin(27, Pin.IN), Pin(26, Pin.IN),Pin(25, Pin.IN), Pin(32, Pin.IN)]
# Botonoes del jugador 2
btn_j2 = [Pin(4, Pin.IN), Pin(15, Pin.IN),Pin(18, Pin.IN), Pin(2, Pin.IN)]

btn_simon = Pin(14, Pin.IN)  
btn_fin = Pin(13, Pin.IN,Pin.PULL_UP)
BUZER = Pin(23, Pin.OUT)  #Pin al que va conectado el buzzer y se establece que es una salida
# Variables del juego
Pts1 = Pts2 = n_ronda = 0 #Asignacion multivariable y se inicializa en 0
n_jug = 1  #Numero de jugadores 
simond = Fin = False #Banderas de control y se le asigna que aun no estan activos

# Variables para antirebote de botones
antirebote_ms = 50
simon_c = 1
simon_tiempo_c = 0
simon_estab = 1
fin_c = 1
fin_tiempo_c = 0
fin_estab = 1
 
def leer_btnes(): #Función de antirrebote
    #Se crean variables globales para indicarle al programa que se van a modificar en dicha funcion
    global simond, Fin
    global simon_c, simon_tiempo_c, simon_estab
    global fin_c, fin_tiempo_c, fin_estab
    ahora = time.ticks_ms()   #Le estamos asignando la lectura actual en ahora 
    # Revisión del estado del boton de SIMON
    validar = btn_simon.value()  #Guardamos el ultimos estado del boton de simon en validar
    if validar != simon_c:   #Si validar y la lectura cruda de simon son diferentes le decimos al programa que :
        simon_c = validar #Cambiamos el nuevo estado del boton
        simon_tiempo_c = ahora  #El instante en el que ocurrio el cambio
    #Vamos a revisar si el cambio de estado supero el tiempo de antirebote
    if time.ticks_diff(ahora, simon_tiempo_c) > antirebote_ms: #Si el tiempo de cambio supero el antirebote entonces
        if simon_estab == 1 and simon_c == 0: #Si se detecta un flanco de bajada
            simond = True #El modo simon se activa y se va a la interrupción
        simon_estab = simon_c #Se actualiza el nuevo estado para la señal cruda del boton simon
    # Botón FIN
    validar = btn_fin.value()   #Comprobamos el estado del botn de fin
    if validar != fin_c:  #Si el estado estable del boton cambio
        fin_c = validar  #Guardamos el nuevo valor
        fin_tiempo_c = ahora #Guardamos el instante en el que ocurrio
    if time.ticks_diff(ahora, fin_tiempo_c) > antirebote_ms:  #Se comprueba que si el cambio dura mas tiempo que el antirebote
        if fin_estab == 1 and fin_c == 0: #Si existe un flanco de bajada
            Fin = True #Se sale del juego 
        fin_estab = fin_c #Se guarda el estado estable 
 
#Control de leds,  por registros
def led_encen(n): #Funcion para encender leds
    mem32[OUT] |= LEDS[n-1]  #Me encience el led que corresponda
 
def led_apag(n): #Funcion para apagar leds
    mem32[OUT] &= ~LEDS[n-1] #me apaga el led que corresponda
 
def leds_apgds(): #Funcion para apagar todos los leds
    mem32[OUT] &= ~(LEDS[0]|LEDS[1]|LEDS[2]) 
 
#Control del buzzer
def B(v):
    BUZER.value(v)

#Visualización de puntajes
def Pts():
    print(f"\n El jugador 1 tiene {Pts1} de puntos" + (f" El jugador 2 tiene {Pts2} de puntos" if n_jug==2 else "") + " ---") #imprime la cantidad de puntos de cada jugador
#Funcion para entrar al modo simon dice
def simon_juego():
    global Pts1, simond, Fin
    print("\n Para usar el modo SIMON DICE usa los controles del jugador 1")
    btns_j1 = btn_j1[:4]
    estimulos = [1,2,3,4]
    secuencia = []
    r = 1
    jug_perdio = False
    time.sleep(1)
    while not jug_perdio and not Fin and simond:
        print(f"Ronda {r}")
        time.sleep(1)
        secuencia.append(random.randint(0,3))
        # Mostrar secuencia
        for i in secuencia:
            leer_btnes()  # por si acaso
            e = estimulos[i]
            if e <= 3:
                led_encen(e)
                time.sleep(0.8)
                led_apag(e)
            else:
                B(1)
                time.sleep(0.8)
                B(0)
            time.sleep(0.3)
        # Turno del jugador
        for esp in secuencia:
            print("Es tu turno")
            b_pres = None
            while b_pres is None and not Fin and simond:
                leer_btnes()
                for i, b in enumerate(btns_j1):
                    if b.value():
                        time.sleep(0.05)
                        if b.value():
                            b_pres = i
                            # Feedback inmediato
                            if i <= 2:
                                led_encen(i+1)
                                time.sleep(0.2)
                                led_apag(i+1)
                            else:
                                B(1)
                                time.sleep(0.2)
                                B(0)
                            while b.value():
                                leer_btnes()  # permite salir si se pulsa fin
                                time.sleep(0.05)
                            break
                time.sleep(0.01)
            if Fin or not simond:
                break
            if b_pres == esp:
                print(" ACERTASTE!")
                # Solo ilumina el LED o buzzer correspondiente
                if b_pres <= 2:
                    led_encen(b_pres + 1)
                    time.sleep(0.3)
                    led_apag(b_pres + 1)
                else:
                    B(1)
                    time.sleep(0.3)
                    B(0)
                time.sleep(0.2)
            else:
                print("INCORRECTO!")
                jug_perdio = True
                Pts1 += r * 50
                print(f"Bonus +{r*50}")
                for _ in range(3):
                    B(1)
                    time.sleep(0.2)
                    B(0)
                    time.sleep(0.2)
                break
        r += 1
        time.sleep(1)
    leds_apgds()
    B(0)
    print("Regresando al juego de reflejos")
    simond = False
 
# Selección de modo al inicio
print("JUEGO DE REFLEJOS!")
print("Presiona el botón de inicio (I)")
while not btninicio.value():
    leer_btnes()
    time.sleep(0.1)
time.sleep(0.3)
 
print("(Para UN jugador presiona 1 vez, para DOS jugadores presiona 2 veces")
c, t0 = 0, time.ticks_ms()
while time.ticks_diff(time.ticks_ms(), t0) < 5000:
    leer_btnes()
    if btninicio.value():
        c += 1
        print(f"Lo pulsaste {c} veces")
        while btninicio.value():
            leer_btnes()
            time.sleep(0.05)
        time.sleep(0.2)
n_jug = 2 if c >= 2 else 1 #define si el juego será de uno o dos jugadores según número de pulsaciones
print(f"\n{' 2' if n_jug==2 else ' 1'} jugadores")
print("Para entrar al modo simon presiona (S) para finalizar el juego presiona (F)")
Pts()
 
# Bucle principal del sistema, lo ejecuta hasta que se presione el botón de finalización
while not Fin:
    leer_btnes()
    if simond:
        simon_juego()
        continue
 
    n_ronda += 1
    print(f"\n RONDA {n_ronda}")
 
    # Espera aleatoria (1-10s) con chequeo de botones
    esp = random.randint(1,6 )
    print(f"Tienes que esperar {esp}s")
    t = time.ticks_ms()
    while time.ticks_diff(time.ticks_ms(), t) < esp * 1000:
        leer_btnes()
        if simond or Fin:
            break
        time.sleep(0.1)
    if simond or Fin:
        continue
 
    # Estímulo aleatorio (1..4)
    estimulos = random.randint(1, 4)
    if estimulos <= 3:
        led_encen(estimulos)
        print(f"LED{estimulos} esta encendido")
    else:
        B(1)
        print("El buzzer esta encendido")
 
    t0 = time.ticks_ms()
    t1 = t2 = None
    ok1 = ok2 = err1 = err2 = False
 
    # Ventana de 3 segundos para responder
    while time.ticks_diff(time.ticks_ms(), t0) < 3000:
        leer_btnes()
        if simond or Fin:
            break
        ahora = time.ticks_ms()
 
        # Jugador 1
        if t1 is None:
            for i, b in enumerate(btn_j1):
                if b.value():
                    while b.value():
                        leer_btnes()
                        time.sleep(0.05)
                    if i + 1 == estimulos:
                        t1 = time.ticks_diff(ahora, t0)
                        ok1 = True
                        print(f"El jugador 1 acerto en {t1} ms")
                    else:
                        t1 = 3000
                        err1 = True
                        print("Jugador 1 incorrecto -50 puntos")
                        for _ in range(2):
                            B(1)
                            time.sleep(0.1)
                            B(0)
                            time.sleep(0.05)
                    break
 
        # Jugador 2 (si lo hay)
        if n_jug == 2 and t2 is None:
            for i, b in enumerate(btn_j2):
                if b.value():
                    while b.value():
                        leer_btnes()
                        time.sleep(0.05)
                    if i + 1 == estimulos:
                        t2 = time.ticks_diff(ahora, t0)
                        ok2 = True
                        print(f"El jugador 2 acerto en {t2} ms")
                    else:
                        t2 = 3000
                        err2 = True
                        print("El jugador 2 incorrecto -50 puntos")
                        for _ in range(2):
                            B(1)
                            time.sleep(0.1)
                            B(0)
                            time.sleep(0.05)
                    break
    
        if n_jug == 1 and t1 is not None:
            break
        if n_jug == 2 and t1 is not None and t2 is not None:
            break
        time.sleep(0.01)
 
    # Apagar estímulo
    if estimulos <= 3:
        led_apag(estimulos)
    else:
        B(0)
 
    if simond or Fin:
        continue
 
    # Asignar tiempos por defecto si no respondieron
    if t1 is None:
        t1 = 3000
        print("J1 sin respuesta")
    if n_jug == 2 and t2 is None:
        t2 = 3000
        print("J2 sin respuesta")
 
    pts_1 = max(0, int((3000 - t1) * 0.1)) if ok1 else (-50 if err1 else 0)
    pts_2 = max(0, int((3000 - t2) * 0.1)) if ok2 else (-50 if err2 else 0) if n_jug == 2 else 0
    Pts1 += pts_1
    Pts2 += pts_2
 
    print(f"Ronda {n_ronda}: J1 {pts_1} ({t1}ms)" + (f" J2 {pts_2} ({t2}ms)" if n_jug == 2 else ""))
    Pts()
    time.sleep(2)
 
# Fin del juego
print("\n FIN DEL JUEGO")
Pts()
if n_jug == 1:
    print(f"El jugador obtuvo {Pts1}")
else:
    if Pts1 > Pts2:
        print("GANA EL JUGADOR 1")
    elif Pts2 > Pts1:
        print("GANA EL JUGADOR 2")
    else:
        print("EMPATE")
for _ in range(3):
    B(1)
    time.sleep(0.2)
    B(0)
    time.sleep(0.2)
print("Gracias por participar")