from machine import Pin, I2C, PWM
from time import ticks_ms, ticks_diff
import ssd1306, random

# OLED
i2c = I2C(0, scl=Pin(26), sda=Pin(27))
oled = ssd1306.SSD1306_I2C(128, 64, i2c)
if not hasattr(oled, "fill_rect"):
    oled.fill_rect = oled.framebuf.fill_rect

# BOTONES
up_btn = Pin(12, Pin.IN, Pin.PULL_UP)  #amarillo
down_btn = Pin(14, Pin.IN, Pin.PULL_UP)  #negro
start_btn = Pin(13, Pin.IN, Pin.PULL_UP)  #verde

last_up = last_down = last_start = 0

def read_buttons():
    global last_up,last_down,last_start
    now = ticks_ms()
    u=d=s=False
    if up_btn.value()==0 and ticks_diff(now,last_up)>150:
        last_up=now; u=True
    if down_btn.value()==0 and ticks_diff(now,last_down)>150:
        last_down=now; d=True
    if start_btn.value()==0 and ticks_diff(now,last_start)>150:
        last_start=now; s=True
    return u,d,s

# BUZZER
buzzer = PWM(Pin(19))
buzzer.duty(0)

def beep(f,d):
    buzzer.freq(f); buzzer.duty(512)
    import time; time.sleep_ms(d)
    buzzer.duty(0)

def mario_lose():
    beep(784,120); beep(659,120); beep(523,150); beep(392,220)

def mario_win():
    beep(523,90); beep(659,90); beep(784,90); beep(1047,180)

def pause_sound():
    beep(880,70); beep(660,90)

def jump_sound():
    beep(1200,40)

# MUSICA SOLO TIME
music_notes = [262,196,196,220,196,0,247,262]
music_index = 0
music_timer = 0

def music_update(now):
    global music_index, music_timer
    if ticks_diff(now, music_timer) > 180:
        music_timer = now
        note = music_notes[music_index]
        if note == 0:
            buzzer.duty(0)
        else:
            buzzer.freq(note)
            buzzer.duty(200)
        music_index = (music_index + 1) % len(music_notes)

# SPRITE
CRAB1 = [
"00111000","01000010","10100101","11111111",
"10111101","11111111","01011010","10000001",
]
CRAB2 = [
"00111000","01000010","10100101","11111111",
"10111101","11111111","00100100","01000010",
]

def draw_sprite(s,x,y):
    for r,row in enumerate(s):
        for c,p in enumerate(row):
            if p=="1":
                oled.pixel(x+c,y+r,1)

# ESTADOS
MENU,GAME,PAUSE,OVER,WIN = 0,1,2,3,4
state=MENU
mode=0
modes=["CLASICO","TIME","HARDCORE"]

# PLAYER
x=10
y=40
vel=0
gravity=2
jump=-11

# GAME
obs=[]
last_spawn=0
spawn_delay=1200
start_time=0
score=0
speed=2

prev_score_time = 0
beat_record = False

frame=0
last_anim=0

# HITBOX
P_W, P_H = 6, 6
P_OFF = 1

def reset():
    global y,vel,obs,score,start_time,speed,last_spawn
    global prev_score_time, beat_record

    if mode==1:
        prev_score_time = score

    y = 32 if mode==1 else 40
    vel=0
    obs=[]
    score=0
    start_time=ticks_ms()
    last_spawn=ticks_ms()
    beat_record = False

    if mode==0:
        speed = 3
    elif mode==2:
        speed = 7
    else:
        speed = 2

def spawn(now):
    global last_spawn, spawn_delay, speed

    if ticks_diff(now,last_spawn) > spawn_delay:

        if mode==1:
            gap_y = random.randint(20, 40)
            gap_h = 22
            obs.append([128, 0, gap_y - gap_h//2])
            obs.append([128, gap_y + gap_h//2, 64 - (gap_y + gap_h//2)])
            spawn_delay = random.randint(1100, 1800)

        else:
            size = random.choice([5,10])
            obs.append([128, 48-size, size])

            if mode==2:
                spawn_delay = random.randint(500,900)
            else:
                spawn_delay = random.randint(800,1400)

        last_spawn = now

def collide(px,py, ox,oy, ow,oh):
    px += P_OFF; py += P_OFF
    return not (px+P_W <= ox or ox+ow <= px or py+P_H <= oy or oy+oh <= py)

def update(now, up, down):
    global y,vel,score,speed,beat_record

    if mode==1:
        target = 0
        if up: target = -2
        if down: target = 2

        vel += (target - vel)*0.25
        y += vel

        if y<0: y=0
        if y>56: y=56

    else:
        if up and y>=40:
            vel = jump
            jump_sound()

        vel += gravity
        if vel>10: vel=10
        y += vel

        if y>=40:
            y=40
            vel=0

    # 🔥 ESCALADO REAL EN CLÁSICO
    if mode==0:
        elapsed = ticks_diff(now, start_time) // 1000
        speed = 3 + (elapsed // 5)
    elif mode==2:
        speed += 0.004
    else:
        speed += 0.002

    for o in obs:
        o[0] -= speed

    new=[]
    for o in obs:
        if o[0]>-10:
            new.append(o)
        else:
            score+=1
            if mode==1 and not beat_record and score > prev_score_time:
                beep(1500,80)
                beat_record = True

    obs[:] = new

    for o in obs:
        if collide(x,int(y), int(o[0]), int(o[1]), 6, int(o[2])):
            mario_lose()
            return False

    if mode==1 and ticks_diff(now,start_time) > 45000:
        return "time"

    return True

def draw():
    oled.fill(0)

    if mode!=1:
        oled.fill_rect(0,48,128,2,1)

    global frame,last_anim
    if ticks_diff(ticks_ms(),last_anim) > 150:
        frame = 1-frame
        last_anim = ticks_ms()

    draw_sprite(CRAB1 if frame==0 else CRAB2, x, int(y))

    for o in obs:
        oled.fill_rect(int(o[0]), int(o[1]), 6, int(o[2]), 1)

    if mode==1:
        t = 45 - ticks_diff(ticks_ms(),start_time)//1000
        oled.text("S:"+str(score),0,0)
        oled.text("O:"+str(prev_score_time),45,0)
        oled.text("T:"+str(t),90,0)
    else:
        oled.text("S:"+str(score),0,0)

    oled.show()

def draw_menu():
    oled.fill(0)
    oled.text("MENU",40,0)
    for i,m in enumerate(modes):
        if i==mode:
            oled.text(">",10,20+i*10)
        oled.text(m,20,20+i*10)
    oled.show()

def draw_pause():
    oled.fill(0)
    oled.text("PAUSA",40,20)
    oled.text("START=SEGUIR",18,36)
    oled.show()

last_frame=0

while True:
    now=ticks_ms()
    if ticks_diff(now,last_frame) < 33:
        continue
    last_frame = now

    up,down,start = read_buttons()

    if state==MENU:
        draw_menu()
        if up:
            mode=(mode-1)%3; beep(900,40)
        if down:
            mode=(mode+1)%3; beep(900,40)
        if start:
            reset(); state=GAME

    elif state==GAME:

        if mode==1:
            music_update(now)

        if start:
            pause_sound()
            state=PAUSE
            continue

        if ticks_diff(now,start_time) > 2000:
            spawn(now)

        result = update(now, up, down)
        draw()

        if result == False:
            state=OVER
        elif result == "time":
            state=WIN

    elif state==PAUSE:
        draw_pause()
        if start:
            pause_sound()
            state=GAME

    elif state==OVER:
        oled.fill(0)
        oled.text("GAME OVER",20,20)
        oled.text("Score:"+str(score),20,35)
        oled.show()
        if start:
            state=MENU

    elif state==WIN:
        oled.fill(0)
        oled.text("TIME!",40,20)
        oled.text("Score:"+str(score),20,35)
        oled.show()
        if start:
            state=MENU